﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    /// <summary>
    /// Base user class
    /// </summary>
    internal abstract class User
    {
        // Information users must provide to register
        private string _name;
        private int _age;
        private string _mobile;
        private string _email;
        private string _password;

        // Abstract age property to be implemented by the dervied class
        protected abstract (int minAge, int maxAge) AgeRange { get; }

        // Get & Set properties
        public string Name
        {
            get => _name;
            set
            {
                // Ensures name contains at least one character and only letters and spaces.
                if (string.IsNullOrEmpty(value) || !System.Text.RegularExpressions.Regex.IsMatch(value, @"[A-Za-z\s]+$"))
                {
                    CmdLineUI.DisplayError("Name must contain at least one letter and only letters and spaces.");
                }
                else
                {
                    _name = value;
                }
            }
        }

        public int Age
        {
            get => _age;
            set
            {
                var (minAge, maxAge) = AgeRange;

                // Age validation logic
                if (value < minAge || value > maxAge)
                {
                    CmdLineUI.DisplayError($"Age must be between {minAge} and {maxAge}.");
                }
                else
                {
                    _age = value;
                }
            }
        }

        public string Mobile
        {
            get => _mobile;
            set
            {
                //// Mobile must be 10 digits long with a leading 0
                //if (value.Length != 10 || !value.All(char.IsDigit) || value[0] != '0')
                //{
                //    throw new ArgumentException("Mobile must consist of numbers, be exactly 10 digits and have a leading zero.");
                //}
                _mobile = value; // test only
            }
        }

        public string Email
        {
            get => _email;
            set
            {
                //// Email must contain an @ symbol and at least one character on either side
                //if (!value.Contains('@') || value.IndexOf('@') == 0 || value.IndexOf('@') == value.Length - 1)
                //{
                //    throw new ArgumentException("Email must contain an @ character and at least one character on either side.");
                //}
                //else
                //{
                //    _email = value;
                //}
                _email = value; // test only, change later
            }
        }

        public string Password
        {
            get => _password;
            set
            {
                //// Password validation logic
                //if (value.Length <= 8 || !value.Any(char.IsUpper) && !value.Any(char.IsLower) && !value.Any(char.IsDigit))
                //{
                //    CmdLineUI.DisplayError("Password must be at least 8 characters long, use both numbers and letters, and at least one upper and lower case letter.");
                //}
                //else
                //{
                //    _password = value;
                //}
                _password = value;
            }
        }

        /// <summary>
        /// Initialises an instace of user class
        /// </summary>
        /// <param name="name">The user's name</param>
        /// <param name="age">The user's age</param>
        /// <param name="email">The user's email</param>
        /// <param name="mobile">The user's mobile</param>
        /// <param name="password">The user's password</param>
        public User(string name, int age, string mobile, string email, string password)
        {
            Name = name;
            Age = age;
            Mobile = mobile;
            Email = email;
            Password = password;
        }

        // To be implemented by derived classes
        public abstract void DisplayDetails();
    }
}
