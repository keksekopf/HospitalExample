﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    internal class Menu
    {
        private AccountServices _accountServices;
        private readonly Database _database;

        /// <summary>
        /// Creates an instance of the menu class
        /// </summary>
        /// <param name="hospital">The hospital which the menu is used for</param>
        public Menu(Hospital hospital)
        {
            _database = hospital.Database;
            _accountServices = new AccountServices(hospital); // Pass the shared Hospital & Database instance to AccountServices

            //// testing purposes
            //_accountServices.Register("Corgi Dog", 23, "0437324985", "patient", "Password.01");
            //_accountServices.Register("Husky Dog", 18, "0437324985", "patient2", "Password.01");
            //_accountServices.Register("Big Giraffe", 55, "0457463729", "floormanager", "Password.01", 435, 3);
            //_accountServices.Register("Chonky Cat", 45, "0545435943", "surgeon", "Password.01", 666, "General Surgeon");
        }

        /// <summary>
        /// Display the header and runs the menu.
        /// </summary>
        public void Run()
        {
            DisplayHeader();
            bool active = true;
            // Keep running the menu until the user chooses to exit the program
            // This will be when the user selects exit in the DisplayMainMenu method
            while (active)
            {
                active = DisplayMainMenu();
            }
        }

        /// <summary>
        /// Displays the main heading.
        /// </summary>
        private void DisplayHeader()
        {
            CmdLineUI.DisplayMessage("=================================");
            CmdLineUI.DisplayMessage("Welcome to Gardens Point Hospital");
            CmdLineUI.DisplayMessage("=================================");
        }

        private bool DisplayMainMenu()
        {            
            CmdLineUI.DisplayMessage();

            // The main menu strings
            const string MAINMENU_STR = "Please choose from the menu below:"; // Main menu prompt
            const string LOGIN_STR = "Login as a registered user"; // Menu option 1
            const string REGISTER_STR = "Register as a new user"; // Menu option 2
            const string EXIT_STR = "Exit"; // Menu option 3

            // Int for each option above
            const int LOGIN_INT = 0, REGISTER_INT = 1, EXIT_INT = 2;

            // Display the menu
            int option = CmdLineUI.GetOption(MAINMENU_STR, LOGIN_STR, REGISTER_STR, EXIT_STR);

            // Make a selection based on user input from the CmdLineUI.GetOption method.
            Action selection = option switch
            {
                LOGIN_INT => Login,
                REGISTER_INT => RegisterUser,
                EXIT_INT => () => 
                {
                    Exit();
                    return;
                },
                _ => () => 
                {
                    CmdLineUI.DisplayMessage("Wrong main menu choice");
                }
            };

            // Invoke the method
            selection.Invoke();

            // Exit loop if user exits program
            return option != EXIT_INT;
        }

        private void PatientMenu()
        {
            // Patient menu strings
            const string PATIENT_MENU_STR = "Patient Menu.\nPlease choose from the menu below:";
            const string VIEW_ROOM_STR = "See room";
            const string VIEW_SURGEON_STR = "See surgeon";
            const string VIEW_SURGERY_STR = "See surgery date and time";

            // Int for each option above
            const int DISPLAY_DETAILS_INT = 0;
            const int CHANGE_PASSWORD_INT = 1;
            const int CHECK_IN_INT = 2;
            const int VIEW_ROOM_INT = 3;
            const int VIEW_SURGEON_INT = 4;
            const int VIEW_SURGERY_INT = 5; 
            const int LOGOUT_INT = 6;

            // Continue running the menu until the user logs out
            bool active = true;

            while (active)
            {
                CmdLineUI.DisplayMessage();

                // Dynamic string that displays check in/check out option based on patient's status
                string checkInOutStr = (_accountServices.CurrentUser as Patient)?.CheckedIn == true ? "Check out" : "Check in";

                // Display the menu
                int option = CmdLineUI.GetOption(PATIENT_MENU_STR, FormatConsts.DISPLAY_DETAILS, FormatConsts.CHANGE_PASSWORD, checkInOutStr, VIEW_ROOM_STR, VIEW_SURGEON_STR, VIEW_SURGERY_STR, FormatConsts.LOGOUT);

                // Make a selection based on user input
                Action selection = option switch
                {
                    DISPLAY_DETAILS_INT => ((Patient)_accountServices.CurrentUser).DisplayDetails, // Display details
                    CHANGE_PASSWORD_INT => _accountServices.ChangePassword, // Change password
                    CHECK_IN_INT => ((Patient)_accountServices.CurrentUser).CheckInOut, // Decides which method to call depending on the state of the patient's checkedIn boolean
                    VIEW_ROOM_INT => ((Patient)_accountServices.CurrentUser).DisplayRoomDetails,
                    VIEW_SURGEON_INT => ((Patient)_accountServices.CurrentUser).DisplaySurgeonDetails,
                    VIEW_SURGERY_INT => ((Patient)_accountServices.CurrentUser).DisplaySurgeryDetails,
                    LOGOUT_INT => () =>
                    {
                        _accountServices.Logout();
                        active = false; // Break the loop when logging out
                    },
                    _ => () => CmdLineUI.DisplayError("Invalid option"),
                };

                // Run user selection
                selection.Invoke();
            }
        }

        private void FloorManagerMenu()
        {
            // Floor manager menu strings
            const string FLOORMNGR_MENU = "Floor Manager Menu.\nPlease choose from the menu below:";
            const string ASSIGN_ROOM = "Assign room to patient";
            const string ASSIGN_SURGERY = "Assign surgery";
            const string UNASSIGN_ROOM = "Unassign room";

            const int DISPLAY_DETAILS_INT = 0;
            const int CHANGE_PASSWORD_INT = 1;
            const int ASSIGN_ROOM_INT = 2;
            const int ASSIGN_SURGERY_INT = 3;
            const int UNASSIGN_ROOM_INT = 4;
            const int LOGOUT_INT = 5;

            // Continue running menu until user logs out
            bool active = true;

            while (active)
            {
                CmdLineUI.DisplayMessage();

                // Display the menu
                int option = CmdLineUI.GetOption(FLOORMNGR_MENU, FormatConsts.DISPLAY_DETAILS, FormatConsts.CHANGE_PASSWORD, ASSIGN_ROOM, ASSIGN_SURGERY, UNASSIGN_ROOM, FormatConsts.LOGOUT);

                // Make a selection based on user input
                Action selection = option switch
                {
                    DISPLAY_DETAILS_INT => ((FloorManager)_accountServices.CurrentUser).DisplayDetails,
                    CHANGE_PASSWORD_INT => _accountServices.ChangePassword,
                    2 => ((FloorManager)_accountServices.CurrentUser).PatientRoomAssignment,
                    3 => ((FloorManager)_accountServices.CurrentUser).ScheduleSurgery,
                    4 => ((FloorManager)_accountServices.CurrentUser).PatientRoomAssignment,
                    5 => () =>
                    {
                        _accountServices.Logout();
                        active = false; // Break the menu loop;
                    },
                    _ => () => CmdLineUI.DisplayError("Invalid option"),
                };

                selection.Invoke();
            }
        }

        private void SurgeonMenu()
        {
            // Surgeon menu strings
            const string SURGEON_MENU = "Surgeon Menu.\nPlease choose from the menu below:";
            const string VIEW_PATIENTS = "See your list of patients";
            const string VIEW_SCHEDULE = "See your schedule";
            const string PERFORM_SURGERY = "Perform surgery";

            // Continue running menu until user logs out
            bool active = true;

            while (active)
            {
                CmdLineUI.DisplayMessage();

                // Display the menu
                int menuOption = CmdLineUI.GetOption(SURGEON_MENU, FormatConsts.DISPLAY_DETAILS, FormatConsts.CHANGE_PASSWORD, VIEW_PATIENTS, VIEW_SCHEDULE, PERFORM_SURGERY, FormatConsts.LOGOUT);

                // Make a selection based on user input
                Action selection = menuOption switch
                {
                    0 => ((Surgeon)_accountServices.CurrentUser).DisplayDetails,
                    1 => _accountServices.ChangePassword,
                    2 => ((Surgeon)_accountServices.CurrentUser).ViewPatients,
                    3 => ((Surgeon)_accountServices.CurrentUser).ViewSurgerySchedule,
                    4 => ((Surgeon)_accountServices.CurrentUser).PerformSurgery,
                    5 => () =>
                    {
                        _accountServices.Logout();
                        active = false; // Break the menu loop
                    },
                    _ => () => CmdLineUI.DisplayError("Invalid option"),
                };

                selection.Invoke();
            }

        }

        /// <summary>
        /// Allows a user to authenticate themselves and log into the system.
        /// </summary>
        private void Login()
        {
            CmdLineUI.DisplayMessage();

            // Get the user's credentials
            CmdLineUI.DisplayMessage("Login Menu.");
            CmdLineUI.DisplayMessage("Please enter in your email:");
            string email = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your password:");
            string password = CmdLineUI.GetString();

            // Attempt to log in using the supplied credentials
            bool loginSuccessful = _accountServices.Login(email, password);

            if (loginSuccessful)
            {
                CmdLineUI.DisplayMessage($"Hello {_accountServices.CurrentUser.Name} welcome back."); // Notify the user they have logged in.

                Action userMenu = _accountServices.CurrentUser switch
                {
                    Patient patient => PatientMenu,
                    FloorManager floorManager => FloorManagerMenu,
                    Surgeon surgeon => SurgeonMenu,
                    _ => () => CmdLineUI.DisplayMessage("user type issue, idk why this would be a thing")
                };

                userMenu.Invoke();
            }
            else
            {
                CmdLineUI.DisplayMessage("Login unsuccesful");
            }
        }

        /// <summary>
        /// Prompts the user for which type of account they would like to register.
        /// </summary>
        private void RegisterUser()
        {
            CmdLineUI.DisplayMessage();

            // The registration menu strings
            const string REGISTER_MENU_STR = "Register as which type of user:"; // Registration menu prompt
            const string REGISTER_PATIENT_STR = "Patient"; // Menu option 1
            const string REGISTER_STAFF_STR = "Staff"; // Menu option 2
            const string RETURN_STR = "Return to the first menu"; // Menu option 3

            // Int for each option above
            const int REGISTER_PATIENT_INT = 0, REGISTER_STAFF_INT = 1, RETURN_INT = 2;

            // Display the menu
            int option = CmdLineUI.GetOption(REGISTER_MENU_STR, REGISTER_PATIENT_STR, REGISTER_STAFF_STR, RETURN_STR);

            // Make selection based on user input from the CmdLineUI.GetOption method
            Action selection = option switch
            {
                REGISTER_PATIENT_INT => RegisterPatient,
                REGISTER_STAFF_INT => RegisterStaff,
                RETURN_INT => () =>
                {
                    return;
                },
                _ => () =>
                {
                    CmdLineUI.DisplayError("Wrong menu choice");
                    RegisterUser(); // Continues displaying menu until valid choice is selected.
                }
            };

            // Invoke the method
            selection.Invoke();
        }

        private void Exit()
        {
            CmdLineUI.DisplayMessage("Goodbye. Please stay safe.");
        }

        /// <summary>
        /// Registers a patient account into the system.
        /// </summary>
        private void RegisterPatient()
        {
            CmdLineUI.DisplayMessage("Registering as a patient.");

            // Get information from the user
            CmdLineUI.DisplayMessage("Please enter in your name:");
            string name = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your age:");
            int age = CmdLineUI.GetInt();
            CmdLineUI.DisplayMessage("Please enter in your mobile number:");
            string mobile = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your email:");
            string email = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your password:");
            string password = CmdLineUI.GetString();

            // Create the new user and indicate success
            _accountServices.Register(name, age, mobile, email, password);
        }

        /// <summary>
        /// Prompts the user for which type of staff account to register as.
        /// </summary>
        private void RegisterStaff()
        {
            CmdLineUI.DisplayMessage();

            // Staff registration prompts
            const string STAFF_CHOICE = "Register as which type of staff:";
            const string FLOORMNGR = "Floor manager";
            const string SURGEON_STR = "Surgeon";
            const string RETURN_STR = "Return to the first menu";

            // Int for each option above
            const int FLOORMNGR_INT = 0, SURGEON_INT = 1, RETURN_INT = 2;

            // Display the menu
            int option = CmdLineUI.GetOption(STAFF_CHOICE, FLOORMNGR, SURGEON_STR, RETURN_STR);

            // Make selection based on user input
            Action selection = option switch
            {
                FLOORMNGR_INT => RegisterFloorManager,
                SURGEON_INT => RegisterSurgeon,
                RETURN_INT => () => 
                {
                    return;
                },
                _ => () =>
                {
                    CmdLineUI.DisplayError("Wrong menu choice");
                    RegisterStaff(); // Continue displaying menu until valid choice selected
                }
            };

            // Invoke the method
            selection.Invoke();
        }

        /// <summary>
        /// Registers a floor manager user into the system.
        /// </summary>
        private void RegisterFloorManager()
        {
            CmdLineUI.DisplayMessage("Registering as a floor manager.");

            // Get information from the user
            CmdLineUI.DisplayMessage("Please enter in your name:");
            string name = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your age:");
            int age = CmdLineUI.GetInt();
            CmdLineUI.DisplayMessage("Please enter in your mobile number:");
            string mobile = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your email:");
            string email = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your password:");
            string password = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your staff ID:");
            int staffId = CmdLineUI.GetInt(); 
            CmdLineUI.DisplayMessage("Please enter in your floor number:");
            int floorNumber = CmdLineUI.GetInt();

            // Create the new user and indicate success
            _accountServices.Register(name, age, mobile, email, password, staffId, floorNumber);
        }

        /// <summary>
        /// Registers a surgeon user into the system.
        /// </summary>
        private void RegisterSurgeon()
        {
            // Surgeon specialty options
            const string SPECIALTY_STRINGS = "Please choose your speciality:";
            const string GENERAL_SURG_STRING = "General Surgeon";
            const string ORTHO_SURG_STRING = "Orthopaedic Surgeon";
            const string HEART_SURG_STRING = "Cardiothoracic Surgeon";
            const string NEURO_SURG_STRING = "Neurosurgeon";

            // Int for each option above
            const int GENERAL_SURG_INT = 0, ORTHO_SURG_INT = 1, HEART_SURG_INT = 2, NEURO_SURG_INT = 3;

            CmdLineUI.DisplayMessage("Registering as a surgeon.");

            // Get information from the user
            CmdLineUI.DisplayMessage("Please enter in your name:");
            string name = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your age:");
            int age = CmdLineUI.GetInt();
            CmdLineUI.DisplayMessage("Please enter in your mobile number:");
            string mobile = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your email:");
            string email = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your password:");
            string password = CmdLineUI.GetString();
            CmdLineUI.DisplayMessage("Please enter in your staff ID:");
            int staffId = CmdLineUI.GetInt();
            CmdLineUI.DisplayMessage();
            // Surgeon speciality options
            int option = CmdLineUI.GetOption(SPECIALTY_STRINGS, GENERAL_SURG_STRING, ORTHO_SURG_STRING, HEART_SURG_STRING, NEURO_SURG_STRING);
            string specialty = option switch
            {
                GENERAL_SURG_INT => "General Surgeon",
                ORTHO_SURG_INT => "Orthopaedic Surgeon",
                HEART_SURG_INT => "Cardiothoracic Surgeon",
                NEURO_SURG_INT => "Neurosurgeon",
                _ => "???"
            };

            // Create the new user and indicate success
            _accountServices.Register(name, age, mobile, email, password, staffId, specialty);
        }
    }
}
