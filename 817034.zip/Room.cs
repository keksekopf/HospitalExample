﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    internal class Room
    {
        private int _roomNumber;
        // Tells the room which floor it's on
        public int FloorNumber { get; private set; }
        public Patient AssignedPatient { get; private set; }

        public int RoomNumber
        {
            get { return _roomNumber; }
            set
            {
                if (!(value >= 1 && value <= 10))
                {
                    CmdLineUI.DisplayError("Invalid room number");
                }
                else
                {
                    _roomNumber = value;
                }
            }
        }

        public Room(int roomId, int floorNumber)
        {
            RoomNumber = roomId;
            FloorNumber = floorNumber;
        }

        /// <summary>
        /// Assign a patient to a room.
        /// </summary>
        /// <param name="patient"></param>
        /// <returns>True of the room is unoccupied, false otherwise.</returns>
        public bool AssignPatient(Patient patient)
        {
            if (AssignedPatient == null)
            {
                AssignedPatient = patient;
                patient.AssignedRoom = this;
                return true;
            }
            else
            {
                CmdLineUI.DisplayError("Room occupied");
                return false;
            }
        }
    }
}
