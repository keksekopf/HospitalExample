﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    internal class Surgeon : Staff
    {
        private string _speciality;
        private readonly Database _database;

        // Permitted age range for a surgeon
        protected override (int minAge, int maxAge) AgeRange => (30, 75);

        public string Speciality
        {
            get => _speciality;
            set => _speciality = (value == "General Surgeon" || value == "Orthopaedic Surgeon" || value == "Cardiothoracic Surgeon" || value == "Neurosurgeon") ? value : throw new ArgumentException("Specialty not listed.");
        }

        public Surgeon(string name, int age, string mobile, string email, string password, int staffId, string speciality, Database database)
            :base(name, age, mobile, email, password, staffId)
        {
            Speciality = speciality;
            _database = database;
        }

        /// <summary>
        /// Displays a list of patients assigned to this surgeon
        /// </summary>
        public void ViewPatients()
        {
            // Return a list of patients assigned to this surgeon
            var assignedPatients = _database.GetPatientsBySurgeon(this)
                .Select(patient => patient.Name).ToList();

            // Check if there are any assigned patients
            if (!assignedPatients.Any())
            {
                CmdLineUI.DisplayError("No patients are currently assigned to you.");
                return;
            }

            CmdLineUI.DisplayMessage("Your Patients.");

            // Display the list of patients
            for (int i = 0; i < assignedPatients.Count; i++)
            {
                CmdLineUI.DisplayMessage($"{i + 1}. {assignedPatients[i]}");
            }
        }

        public void ViewSurgerySchedule()
        {
            var assignedSurgeries = _database.GetPatientsBySurgeon(this)
                .Select(patient => new
                {
                    // Store the patient's name and surgery details in variables
                    PatientName = patient.Name,
                    SurgeryDateTime = patient.SurgeryDetails.SurgeryDateTime.ToString(FormatConsts.DATETIME_FORMAT) // Format it, need to fix this later
                })
                .OrderBy(schedule => schedule.SurgeryDateTime) // Sort by surgery date and time
                .ToList(); // Convert to a list

            // Check if there are any checked-in patients
            if (!assignedSurgeries.Any())
            {
                CmdLineUI.DisplayError("No patients are currently assigned to you.");
                return;
            }

            CmdLineUI.DisplayMessage("Your schedule.");

            // Iterate over the list of assigned surgeries and display the patient's name and surgery date time
            for (int i = 0; i < assignedSurgeries.Count; i++)
            {
                var schedule = assignedSurgeries[i];
                CmdLineUI.DisplayMessage($"Performing surgery on patient {schedule.PatientName} on {schedule.SurgeryDateTime}");
            }
        }

        /// <summary>
        /// Surgeon performs a virtual surgery
        /// </summary>
        public void PerformSurgery()
        {
            // Return a list of patients assigned to this surgeon
            var assignedPatients = _database.GetPatientsBySurgeon(this);

            // Create a lsit of patient names for display
            var patientNames = assignedPatients.Select(patient => patient.Name).ToList();

            var selectedPatientIndex = CmdLineUI.GetOption("Please select your patient:", patientNames.ToArray());

            if (selectedPatientIndex < 0 || selectedPatientIndex >= assignedPatients.Count)
            {
                CmdLineUI.DisplayError("Invalid selection");
                return;
            }

            Patient selectedPatient = assignedPatients[selectedPatientIndex];

            CmdLineUI.DisplayMessage($"Surgery performed on {selectedPatient.Name} by {this.Name}.");
            selectedPatient.SurgeryDetails = null; // Remove the surgery list from the patient??? Idk, how do you even keep track of this lol
            _database.RemoveSurgerySchedule(selectedPatient);
        }

        /// <summary>
        /// Displays the surgeon's details.
        /// </summary>
        public override void DisplayDetails()
        {
            CmdLineUI.DisplayMessage("Your details.");
            CmdLineUI.DisplayMessage($"Name: {Name}");
            CmdLineUI.DisplayMessage($"Age: {Age}");
            CmdLineUI.DisplayMessage($"Mobile phone: {Mobile}");
            CmdLineUI.DisplayMessage($"Email: {Email}");
            CmdLineUI.DisplayMessage($"Staff ID: {StaffId}");
            CmdLineUI.DisplayMessage($"Speciality: {Speciality}");
        }
    }
}
