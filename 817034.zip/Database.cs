﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    internal class Database
    {
        // List for storing registered users
        public List<User> Users { get; private set; } = new List<User>();
        // List for storing surgery schedules
        private List<SurgerySchedule> _surgerySchedules = new List<SurgerySchedule>();

        /// <summary>
        /// Adds a user to the system
        /// </summary>
        public void AddUser(User user)
        {
            Users.Add(user);
        }

        /// <summary>
        /// Retrieves a user by their email address
        /// </summary>
        /// <param name="email"></param>
        public User GetUserByEmail(string email)
        {
            return Users.FirstOrDefault(user => user.Email == email);
        }

        /// <summary>
        /// Returns a list of users of the specified type.
        /// </summary>
        /// <typeparam name="UserType">The type of user to retrieve.</typeparam>
        private List<UserType> GetUsers<UserType>() where UserType : User
        {
            return Users.OfType<UserType>().ToList();
        }

        /// <summary>
        /// Return a list of patients
        /// </summary>
        public List<Patient> GetPatients()
        {
            return GetUsers<Patient>();
        }

        /// <summary>
        /// Returns a list of surgeons
        /// </summary>
        public List<Surgeon> GetSurgeons()
        {
            return GetUsers<Surgeon>();
        }

        /// <summary>
        /// Adds a scheduled surgery to the database
        /// </summary>
        /// <param name="patient">The patient receiving surgery</param>
        /// <param name="surgeon">The surgeon performing surgery</param>
        /// <param name="surgeryDateTime">The date and time of the surgery</param>
        public void ScheduleSurgery(Patient patient, Surgeon surgeon, DateTime surgeryDateTime)
        {
            var schedule = new SurgerySchedule(patient, surgeon, surgeryDateTime);
            _surgerySchedules.Add(schedule); // Add the schedule to the database
            patient.SurgeryDetails = schedule; // Add the schedule to the patient object (this feels clunky but oh well)
        }

        public void RemoveSurgerySchedule(Patient patient)
        {
            // Find the surgery for the given patient
            var surgerySchedule = _surgerySchedules.FirstOrDefault(s => s.ScheduledPatient == patient);

            // If found, remove it
            if (surgerySchedule != null)
            {
                _surgerySchedules.Remove(surgerySchedule);
            }
        }

        /// <summary>
        /// Returns a list of patients assigned to a specific surgeon.
        /// </summary>
        /// <param name="surgeon">The given surgeon</param>
        /// <returns>A list of Patient objects</returns>
        public List<Patient> GetPatientsBySurgeon(Surgeon surgeon)
        {
            return _surgerySchedules
                .Where(schedule => schedule.AssignedSurgeon == surgeon)
                .Select(schedule => schedule.ScheduledPatient).ToList();
        }
    }
}
