﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    /// <summary>
    /// Patient user functionalities
    /// </summary>
    internal class Patient : User
    {
        public bool CheckedIn { get; private set; }
        // public Room AssignedRoom { get; set; }
        public Room AssignedRoom { get; set; }
        public Floor AssignedFloor { get; set; }
        public SurgerySchedule SurgeryDetails { get; set; }

        // Permitted age range for a patient
        protected override (int minAge, int maxAge) AgeRange => (0, 100);

        public Patient(string name, int age, string mobile, string email, string password)
            : base(name, age, mobile, email, password) { }

        /// <summary>
        /// Checks a patient in or out.
        /// </summary>
        public void CheckInOut()
        {
            //// Check if the patient is booked in for a sugery prior to checking out
            //if (CheckedIn == true && SurgeryDetails != null)
            //{
            //    CmdLineUI.DisplayError("You cannot check out before your scheduled surgery.");
            //    return;
            //}

            CheckedIn = CheckedIn ? false : true; // Shorthand if-else statement
            CmdLineUI.DisplayMessage(CheckedIn ? $"Patient {Name} has been checked in." : $"Patient {Name} has been checked out.");
        }

        /// <summary>
        /// Displays the room details of the patient.
        /// </summary>
        public void DisplayRoomDetails()
        {
            if ( AssignedRoom == null )
            {
                CmdLineUI.DisplayError("You are not assigned a room.");
                return;
            }

            CmdLineUI.DisplayMessage($"Your room is number {AssignedRoom.RoomNumber} on floor {AssignedRoom.FloorNumber}.");
        }

        /// <summary>
        /// Displays the surgeon details of the patient.
        /// </summary>
        public void DisplaySurgeonDetails()
        {
            // Checks if the patient is assigned to a surgeon
            if (SurgeryDetails == null)
            {
                CmdLineUI.DisplayError("You have not been assigned a surgeon.");
                return;
            }
            // else
            CmdLineUI.DisplayMessage($"Your surgeon is {SurgeryDetails.AssignedSurgeon.Name}.");
        }


        /// <summary>
        /// Displays the patient's surgery details.
        /// </summary>
        public void DisplaySurgeryDetails()
        {
            if (SurgeryDetails == null)
            {
                CmdLineUI.DisplayError("You are not scheduled for surgery.");
                return;
            }
            // else
            CmdLineUI.DisplayMessage($"Your surgery time is {SurgeryDetails.FormattedSurgeryDateTime}.");
        }


        /// <summary>
        /// Displays the patient's details.
        /// </summary>
        public override void DisplayDetails()
        {
            CmdLineUI.DisplayMessage("Your details.");
            CmdLineUI.DisplayMessage($"Name: {Name}");
            CmdLineUI.DisplayMessage($"Age: {Age}");
            CmdLineUI.DisplayMessage($"Mobile phone: {Mobile}");
            CmdLineUI.DisplayMessage($"Email: {Email}");
        }
    }
}
