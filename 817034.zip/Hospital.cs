﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    internal class Hospital
    {
        public readonly Database Database;
        public readonly List<Floor> Floors;

        public Hospital()
        {
            Database = new Database();
            Floors = new List<Floor>();
            for (int i = 1; i <=6; i++)
            {
                Floors.Add(new Floor(i));
            }
        }
    }
}
