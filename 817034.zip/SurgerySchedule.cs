﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    /// <summary>
    /// Keeps track of the patient's scheduled surgeries
    /// </summary>
    internal class SurgerySchedule
    {
        public Patient ScheduledPatient { get; set; }
        public Surgeon AssignedSurgeon { get; set; }
        public DateTime SurgeryDateTime {  get; set; }

        public SurgerySchedule (Patient scheduledPatient, Surgeon assignedSurgeon, DateTime surgeryDateTime)
        {
            ScheduledPatient = scheduledPatient;
            AssignedSurgeon = assignedSurgeon;
            SurgeryDateTime = surgeryDateTime;
        }

        public string FormattedSurgeryDateTime
        {
            get { return SurgeryDateTime.ToString(FormatConsts.DATETIME_FORMAT); }
        }
    }
}
