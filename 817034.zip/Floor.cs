﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    internal class Floor
    {
        private int _floorNumber;
        public List<Room> Rooms { get; private set; }
        public FloorManager AssignedManager { get; private set; }

        public int FloorNumber
        {
            get { return _floorNumber; }
            set 
            { 
                if (!(value >= 1 && value <= 6))
                {
                    CmdLineUI.DisplayError("Floor number must be between 1-6.");
                }
                else
                {
                    _floorNumber = value;
                }
            }
        }

        public Floor(int floorNumber, int roomCount = 10)
        {
            FloorNumber = floorNumber;
            Rooms = new List<Room>();

            // Initialise rooms for each floor
            for (int i = 1; i <= roomCount; i++)
            {
                Rooms.Add(new Room(i, floorNumber));
            }
        }

        /// <summary>
        /// Assigns a floor manager to this floor.
        /// </summary>
        /// <param name="manager">The FloorManager to assign.</param>
        public void AssignManager(FloorManager manager)
        {
            if (AssignedManager == null)
            {
                AssignedManager = manager;
            }
            else
            {
                CmdLineUI.DisplayError("This floor already has a manager");
            }
        }

        /// <summary>
        /// Returns the room instance matching the room number in this floor object.
        /// </summary>
        /// <param name="roomNumber">The number of the room to be retrieved.</param>
        /// <returns>The specified room object.</returns>
        public Room GetRoom(int roomNumber)
        {
            return Rooms.FirstOrDefault(r => r.RoomNumber == roomNumber);
        }
    }
}
