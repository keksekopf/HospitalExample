﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    /// <summary>
    /// A set of constants to be used within the program.
    /// </summary>
    public static class FormatConsts
    {
        // The format for the date and time strings.
        public const string DATETIME_FORMAT = "HH:mm dd/MM/yyyy";

        // Common menu choices
        public const string DISPLAY_DETAILS = "Display my details";
        public const string CHANGE_PASSWORD = "Change password";
        public const string LOGOUT = "Log out";
    }
}
