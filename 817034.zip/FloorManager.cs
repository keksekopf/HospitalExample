﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    internal class FloorManager : Staff
    {
        public Floor FloorManaged { get; private set; }
        private readonly Database _database;
        public SurgerySchedule ScheduledSurgery { get; private set; }

        // Permitted age range for a floor manager
        protected override (int minAge, int maxAge) AgeRange => (21, 70);

        /// <summary>
        /// Creates a floor manager instance and connects it to a shared instance of the database using dependency injection.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="age"></param>
        /// <param name="mobile"></param>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <param name="staffId"></param>
        /// <param name="floorManaged"></param>
        /// <param name="hospital"></param>
        /// <param name="database"></param>
        public FloorManager(string name, int age, string mobile, string email, string password, int staffId, Floor floorManaged, Database database)
            :base(name, age, mobile, email, password, staffId)
        {
            FloorManaged = floorManaged;
            _database = database; // Database reference
            FloorManaged.AssignManager(this);
        }

        /// <summary>
        /// Reusable method to retrieve a list of checked in patients.
        /// </summary>
        /// <returns>Returns the selected patient, if any.</returns>
        private Patient RetrievePatients()
        {
            // Return a list of patients currently checked in
            var checkedInPatients = _database.GetPatients().Where(patient => patient.CheckedIn).ToList();

            // Check if there are any checked-in patients
            if (!checkedInPatients.Any())
            {
                CmdLineUI.DisplayError("No patients are currently checked in.");
                return null; // Exit the method
            }

            // Store the retrieved patients in an array
            var patientNames = checkedInPatients.Select(patient => patient.Name).ToArray();

            // Display the list of checked-in patients and return the user's selection
            int selectedPatientIndex = CmdLineUI.GetOption("Please select your patient:", patientNames);

            if (selectedPatientIndex < 0 || selectedPatientIndex >= checkedInPatients.Count)
            {
                CmdLineUI.DisplayError("Invalid selection");
                return null;
            }

            Patient selectedPatient = checkedInPatients[selectedPatientIndex]; // Assign the selected patient to a variable
            return selectedPatient;
        }

        private Surgeon RetrieveSurgeons()
        {
            // Return a list of surgeons from the database
            var surgeons = _database.GetSurgeons();

            // Store the retrieved surgeons in an array
            var surgeonNames = surgeons.Select(surgeon => surgeon.Name).ToArray();

            // Display the list of surgeons and return the user's selection
            int selectedSurgeonIndex = CmdLineUI.GetOption("Please select your surgeon:", surgeonNames);

            if (selectedSurgeonIndex < 0 || selectedSurgeonIndex >= surgeons.Count)
            {
                CmdLineUI.DisplayError("Invalid selection");
                return null;
            }

            Surgeon selectedSurgeon = surgeons[selectedSurgeonIndex];
            return selectedSurgeon;
        }

        /// <summary>
        /// Allows the floor manager to assign a patient to a room if they are checked in.
        /// RECONSIDER ADDING THIS IN THE FLOORMANAGER CLASS - MAYBE IN DATABASE?
        /// </summary>
        public void PatientRoomAssignment()
        {
            var selectedPatient = RetrievePatients();

            if (selectedPatient == null)
            {
                return; // Exit the method is no patients are checked in
            }

            // Ask the user to assign a room
            CmdLineUI.DisplayMessage("Please enter your room (1-10) :");
            int selectedRoom = CmdLineUI.GetInt();
            if (!(selectedRoom >= 1 && selectedRoom <= 10))
            {
                CmdLineUI.DisplayError("Invaid room");
                return;
            }
            else
            {
                Room roomToAssign = FloorManaged.GetRoom(selectedRoom);

                if (roomToAssign.AssignPatient(selectedPatient))
                {
                    CmdLineUI.DisplayMessage($"Patient {selectedPatient.Name} has been assigned to room number {selectedRoom} on floor {FloorManaged.FloorNumber}.");
                }
            }
        }

        public void ScheduleSurgery()
        {
            var selectedPatient = RetrievePatients();

            if (selectedPatient == null)
            {
                return; // Exit the method if no patients are checked in
            }

            var selectedSurgeon = RetrieveSurgeons();

            // Ask the user to select a date and time
            CmdLineUI.DisplayMessage($"Please enter a date and time (e.g. 14:30 31/01/2024).");
            DateTime surgeryDateTime = CmdLineUI.GetDateTime();

            // Create an instance of the SurgerySchedule class and assign it to the patient
            _database.ScheduleSurgery(selectedPatient, selectedSurgeon, surgeryDateTime);
            CmdLineUI.DisplayMessage($"Surgeon {selectedSurgeon.Name} has been assigned to patient {selectedPatient.Name}.");
            CmdLineUI.DisplayMessage($"Surgery will take place on {CmdLineUI.DisplayDateTime(surgeryDateTime)}.");
        }

        public override void DisplayDetails()
        {
            CmdLineUI.DisplayMessage("Your details.");
            CmdLineUI.DisplayMessage($"Name: {Name}");
            CmdLineUI.DisplayMessage($"Age: {Age}");
            CmdLineUI.DisplayMessage($"Mobile phone: {Mobile}");
            CmdLineUI.DisplayMessage($"Email: {Email}");
            CmdLineUI.DisplayMessage($"Staff ID: {StaffId}");
            CmdLineUI.DisplayMessage($"Floor: {FloorManaged.FloorNumber}.");
        }
    }
}
