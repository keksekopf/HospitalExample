﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    internal class AccountServices
    {
        private readonly Database _database;
        private Hospital _hospital;
        public User CurrentUser { get; private set; }

        // Dependency injection
        // AccountServices shares the same hospital database as the Menu class
        public AccountServices(Hospital hospital)
        {
            _hospital = hospital;
            _database = hospital.Database;
        }

        /// <summary>
        /// Registers a new patient
        /// </summary>
        /// <param name="name"></param>
        /// <param name="age"></param>
        /// <param name="email"></param>
        /// <param name="mobile"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool Register(string name, int age, string mobile, string email, string password)
        {
            if (_database.GetUserByEmail(email) != null)
            {
                CmdLineUI.DisplayMessage("USER ALREADY EXISTS");
                return false;
            }

            var newPatient = new Patient(name, age, mobile, email, password);
            _database.AddUser(newPatient);
            CmdLineUI.DisplayMessage($"{name} is registered as a patient.");
            return true;
        }

        /// <summary>
        /// Registers a new floor manager
        /// </summary>
        /// <param name="name"></param>
        /// <param name="age"></param>
        /// <param name="email"></param>
        /// <param name="mobile"></param>
        /// <param name="password"></param>
        /// <param name="staffId"></param>
        /// <param name="floorNumber"></param>
        /// <returns></returns>
        public bool Register(string name, int age, string mobile, string email, string password, int staffId, int floorNumber)
        {
            if (_database.GetUserByEmail(email) != null)
            {
                CmdLineUI.DisplayMessage("USER ALREADY EXISTS");
                return false;
            }

            // Retrieve the specific floor instance using the floor number - my god this is doing my head in
            var floorToManage = _hospital.Floors.FirstOrDefault(f => f.FloorNumber == floorNumber);

            var newFloorManager = new FloorManager(name, age, mobile, email, password, staffId, floorToManage, _database);
            _database.AddUser(newFloorManager); // Add the user to the database            

            CmdLineUI.DisplayMessage($"{name} is registered as a floor manager.");
            return true; // probs not necessary
        }

        /// <summary>
        /// Registers a new surgeon
        /// </summary>
        /// <param name="name"></param>
        /// <param name="age"></param>
        /// <param name="email"></param>
        /// <param name="mobile"></param>
        /// <param name="password"></param>
        /// <param name="staffId"></param>
        /// <param name="specialty"></param>
        /// <returns></returns>
        public bool Register(string name, int age, string mobile, string email, string password, int staffId, string specialty)
        {
            if (_database.GetUserByEmail(email) != null)
            {
                CmdLineUI.DisplayMessage("USER ALREADY EXISTS");
                return false;
            }

            var newSurgeon = new Surgeon(name, age, mobile, email, password, staffId, specialty, _database);
            _database.AddUser(newSurgeon);
            CmdLineUI.DisplayMessage($"{name} is registered as a surgeon.");
            return true;
        }


        /// <summary>
        /// Allows the user to login to the system
        /// </summary>
        /// <param name="email">The user's email</param>
        /// <param name="password">The user's password</param>
        public bool Login(string email, string password)
        {
            // Retrieve user by email
            var user = _database.GetUserByEmail(email);

            // If user exists, verify their password is correct
            if (user != null && user.Password == password)
            {
                CurrentUser = user;
                return true; // Successfully logged in
            }

            // Login failed
            return false;
        }

        /// <summary>
        /// Allows the user to change their password if they are logged in
        /// </summary>
        /// <param name="newPassword">The user's new password</param>
        internal void ChangePassword()
        {
            CmdLineUI.DisplayMessage("Enter new password:");
            string newPassword = CmdLineUI.GetString();
            CurrentUser.Password = newPassword;
            CmdLineUI.DisplayMessage("Password has been changed.");
        }

        /// <summary>
        /// Allows a user to logout
        /// </summary>
        public void Logout()
        {
            string userType = CurrentUser.GetType().Name switch
            {
                "Patient" => "Patient",
                "FloorManager" => "Floor manager",
                "Surgeon" => "Surgeon",
                _ => "Please wtf are you doing to my system"
            };
            CmdLineUI.DisplayMessage($"{userType} {CurrentUser.Name} has logged out.");
            CurrentUser = null; // Logs out current user
        }
    }
}
