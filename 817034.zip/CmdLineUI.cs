﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    /// <summary>
    /// Contains various methods for interacting with the command line.
    /// </summary>
    public static class CmdLineUI
    {
        /// <summary>
        /// Displays a blank line to the screen.
        /// </summary>
        public static void DisplayMessage()
        {
            Console.WriteLine();
        }

        /// <summary>
        /// Displays a message to the screen.
        /// </summary>
        /// <param name="msg">The message to display.</param>
        public static void DisplayMessage(string msg)
        {
            Console.WriteLine(msg);
        }

        /// <summary>
        /// Displays an object's ToString method.
        /// </summary>
        /// <param name="o">The object to convert.</param>
        public static void DisplayMessage(object o)
        {
            Console.WriteLine(o.ToString());
        }

        public static string DisplayDateTime(DateTime dt)
        {
            return dt.ToString(FormatConsts.DATETIME_FORMAT);
        }
        
        /// <summary>
        /// Displays an error message to the screen.
        /// </summary>
        /// <param name="msg">The message to display.</param>
        public static void DisplayError(string msg)
        {
            Console.WriteLine($"Error: {msg}");
        }

        /// <summary>
        /// Displays an error message and asks the user to try again.
        /// </summary>
        /// <param name="msg">The message to display.</param>
        public static void DisplayErrorAgagin(string msg)
        {
            Console.WriteLine($"Error: {msg}, please try again.");
        }

        public static string GetString()
        {
            string input = Console.ReadLine();
            return input;
        }

        /// <summary>
        /// Reads in a string from the console, converts it to an Int32 
        /// and returns the converted value.
        /// </summary>
        /// <returns>An Int32 representation of the user's input.</returns>
        public static int GetInt()
        {
            string input = Console.ReadLine();
            int i = int.Parse(input);
            return i;
        }

        /// <summary>
        /// No idea what this does yet.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns>An Int32 representation of the user's input.</returns>
        public static int GetInt(string msg)
        {
            Console.WriteLine(msg);
            string input = Console.ReadLine();
            int i = int.Parse(input);
            return i;
        }

        /// <summary>
        /// Reads in a string and converts it to a DateTime using the consistent HH:mm dd/MM/yyyy format
        /// All dates must be in this format; abbreivating dates will result in an error
        /// </summary>
        /// <returns>A DateTime representation of the user's input.</returns>
        public static DateTime GetDateTime()
        {
            string input = Console.ReadLine();
            DateTime result;
            string format = FormatConsts.DATETIME_FORMAT; // Expected format is "HH:mm dd/MM/yyyy"
            bool correctFormat = DateTime.TryParseExact(input, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out result);
            if (!correctFormat)
            {
                DisplayError("Incorrect date format");
            }
            return result;
        }

        /// <summary>
        /// Displays a menu, with the options numbered from 1 to options.Length,
        /// then gets a validated integer in the range of 1 - options.Length.
        /// Substracts 1, then returns the result. If the supplied list of options
        /// is empty, returns an error value (-1).
        /// </summary>
        /// <param name="title"></param>
        /// <param name="options"></param>
        /// <returns></returns>
        public static int GetOption(string title, params object[] options)
        {
            // Defensive error checking - There should be at least 1 option
            if (options.Length <= 0)
            {
                // Arbitrary error code
                return -1;
            }

            // Formatting the menu options
            Console.WriteLine(title);
            int digitsNeeded = (int)(1 + Math.Floor(Math.Log10(options.Length)));
            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine($"{(i + 1).ToString().PadLeft(digitsNeeded)}. {options[i]}");
            }

            // Upper limit depends on the number of elements passed
            int option = GetInt($"Please enter a choice between 1 and {options.Length}.");

            // Subtract 1 because computers count from 0
            return option - 1;
        }
    }
}
