﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSystem
{
    /// <summary>
    /// Contains functionalities common to all staff members
    /// </summary>
    internal abstract class Staff : User
    {
        // Fields common to all staff members
        private int _staffId;

        public int StaffId
        {
            get { return _staffId; }
            set
            {
                // Checks if staff ID is > 100 and < 999, inclusive
                if (!(value >= 100 && value <= 999))
                {
                    CmdLineUI.DisplayError("Staff ID must be between 100-999.");
                    return;
                }
                else
                {
                    _staffId = value;
                }
            }
        }

        /// <summary>
        /// Allows users to register with their staff ID
        /// </summary>
        /// <param name="staffId">The user's staff ID</param>
        public Staff(string name, int age, string email, string mobile, string password, int staffId)
            :base(name, age, email, mobile, password)
        {
            StaffId = staffId;
        }

    }
}
