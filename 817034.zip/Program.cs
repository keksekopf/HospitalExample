﻿namespace HospitalSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create an instance of the hospital
            Hospital hospital = new Hospital();

            // Create a menu instance using the hospital's shared database
            Menu menu = new Menu(hospital);

            // Run the menu
            menu.Run();
        }
    }
}
